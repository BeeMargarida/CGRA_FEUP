/* MySubmarine*/
var degToRad = Math.PI / 180.0;

function MySubmarine(scene,x,y,z,angle) {
	CGFobject.call(this,scene);
	this.x = x;
	this.y = y;
	this.z = z;
	this.angle = Math.PI;
	this.w = false;
	this.a = false;
	this.s = false;
	this.d = false;
	
	this.initBuffers();
};

MySubmarine.prototype = Object.create(CGFobject.prototype);
MySubmarine.prototype.constructor=MySubmarine;

MySubmarine.prototype.initBuffers = function () {
	
	this.vertices = [
		0.5, 0.3, 0,
		-0.5, 0.3, 0,
		0, 0.3, 2
	];

	this.indices = [
		0, 1, 2
	];

	this.normals = [
		0, 1, 0,
		0, 1, 0,
		0, 1, 0

	];
    this.initGLBuffers();
};


MySubmarine.prototype.update = function() {
    if(this.a === true){
       this.angle += 5*Math.PI/180;
    }
    if(this.d === true){
        this.angle -= 5*Math.PI/180;
    }
    if(this.w === true){
        this.x += 0.25*Math.sin(this.angle);
        this.z += 0.25*Math.cos(this.angle);
    }
    if(this.s === true){
        this.x -= 0.25*Math.sin(this.angle);
        this.z -= 0.25*Math.cos(this.angle);
    }
}